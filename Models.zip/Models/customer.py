class Customer:
    def __init__(self, c_name, ph_no, city, state, c_id=None):
        self.c_name = c_name
        self.ph_no = ph_no
        self.city = city
        self.state = state
        self.c_id = c_id
